<footer>
<div class="container footer-wrapper">
            <div class="footer-title">
                ForexTradingsite
            </div>
            <div class="text-center footer-links">
                <div class="col-sm-4 final ">
                   

                        <h5>Contact box</h5>
                    

                    <p>Inside the trading room</p>
                    <p>Trading Room Pricing</p>
                    <p>Trading Room Login</p>
                    <p>Best Forex Signals</p>
                </div>
                <div class="col-sm-4  final">
                    
                    <h5>Free resources</h5>
                
                    <p>Knowledge Base</p>
                    <p>Trusted Brokers</p>
                    <p>Currency</p>
                </div>
                <div class="col-sm-4  final">
                  
                    <h5>Forex education</h5>
             
                    <p>Forex Scalping</p>
                    <p>Swing Trading</p>
                    <p>Mentorship Program</p>
                </div>
            </div>
           
            <div class="social-media">
                <div class="social-media-download">
                    <span class="social-media-google"><img src="https://d2dqy7n9gbes77.cloudfront.net/img/download-google.svg" alt=""></span>
                    <span class="social-media-apple"><img src="https://d2dqy7n9gbes77.cloudfront.net/img/download-apple.svg" alt=""></span>
                </div>
                <div class="social-media-links">
                    <span class="social-media-links-title">Let's Stay Connected!</span>
                    <span class="social-media-links-icons"><i class="fab fa-facebook-f"></i><i class="fab fa-twitter"></i><i class="fab fa-instagram"></i>
                        <i class="fab fa-youtube"></i><i class="fab fa-linkedin-in"></i></span>
                </div>

            </div>

            <div class="col-12">
                <hr class="light-100">
                <h5>&copy; forextradingsite.com</h5>
            </div>
        </div>

</footer>
<?php wp_footer();?>

</body>
</html>